﻿using Google.Apis.Services;
using Google.Apis.YouTube.v3;
using YouTubeApiProject.Models;

namespace YouTubeApiProject.Services
{
    // To communicate with the YouTube Data API, using the service class.
    public class YouTubeApiService
    {
        private readonly string _apiKey;

        // Constructor that reads the configuration settings to obtain the API key
        public YouTubeApiService(IConfiguration configuration)
        {
            // Retrieves the configuration's API key.
            _apiKey = configuration["YouTubeApiKey"];
        }

        // An automated technique for using a query string to look for videos on YouTube
        public async Task<List<YouTubeVideoModel>>
       SearchVideosAsync(string query)
        {
            // Using the provided API key, generate an instance of YouTubeService and configure the application name.
            var youtubeService = new YouTubeService(new
           BaseClientService.Initializer()
            {
                ApiKey = _apiKey,
                ApplicationName = "YouTubeApiProject"
            });

            // Use the given query to create a search request for YouTube videos. 
            var searchRequest =
           youtubeService.Search.List("snippet");
            searchRequest.Q = query;
            searchRequest.MaxResults = 10;

            // Perform the search request in an instantaneous way.
            var searchResponse = await
           searchRequest.ExecuteAsync();

            // Create a list of YouTubeVideoModel objects from the search results.
            var videos = searchResponse.Items.Select(item => new
           YouTubeVideoModel
            {
                Title = item.Snippet.Title,
                Description = item.Snippet.Description,
                ThumbnailUrl = item.Snippet.Thumbnails.Medium.Url,
                VideoUrl = "https://www.youtube.com/watch?v=" + item.Id.VideoId
            }).ToList();

            // Return the list of videos
            return videos;
        }
    }
}

