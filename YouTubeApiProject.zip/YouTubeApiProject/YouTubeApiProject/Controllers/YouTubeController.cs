﻿using Microsoft.AspNetCore.Mvc;
using YouTubeApiProject.Models;
using YouTubeApiProject.Services;

namespace YouTubeApiProject.Controllers
{
    // Controller in charge of managing requests for searches on YouTube
    public class YouTubeController : Controller
    {
        //A method to interact with the YouTube API
        private readonly YouTubeApiService _youtubeService;

        // Constructor that uses dependency injection to inject the YouTubeApiService
        public YouTubeController(YouTubeApiService youtubeService)
        {
            _youtubeService = youtubeService;
        }

        // Display Search Page
        public IActionResult Index()
        {
            return View(new List<YouTubeVideoModel>());
        }
        // Handle search query from user
        [HttpPost]
        public async Task<IActionResult> Search(string query)
        {
            // Using the user's query, call the YouTubeApiService to search for videos.
            var videos = await
           _youtubeService.SearchVideosAsync(query);

            //Pass the list of videos and return the search results to the "Index" view.
            return View("Index", videos);
        }
    }

}
