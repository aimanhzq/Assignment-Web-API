//Import the namespace where the YouTubeApiService is located.
using YouTubeApiProject.Services;

// Use the command-line arguments to initialize the WebApplication builder.
var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddScoped<YouTubeApiService>();

// Build the application
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    // Use custom error handling in production mode 
    app.UseExceptionHandler("/Home/Error");

    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

// Redirect HTTP requests to HTTPS
app.UseHttpsRedirection();

// Enable the serving of static files from wwwroot or other designated directories, such as CSS, JS, and pictures.
app.UseStaticFiles();

// To specify how HTTP requests map to controllers and actions, enable routing middleware.
app.UseRouting();

// Although this code does not define any authorization policies, enable authorization middleware.
app.UseAuthorization();

// Set up the default route for MVC pattern
app.MapControllerRoute(

    // Route name
    name: "default",
    
    // Default route pattern
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Run the application
app.Run();


