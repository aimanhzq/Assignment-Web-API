﻿namespace YouTubeApiProject.Models
{

    // This class is a function of a YouTube video model. 
    public class YouTubeVideoModel
    {
        // Property for storing the YouTube video's title. 
        public string Title { get; set; }

        // Property for storing the description of the YouTube video 
        public string Description { get; set; }

        // Property for storing the URL of the YouTube video's thumbnail image. 
        public string ThumbnailUrl {  get; set; }

        // Property for storing the URL of the YouTube video. 
        public string VideoUrl { get; set; }
    }
}

